export const environement = {
    production: false,
    supabaseUrl: 'db.lhbcyinpdgxwhemwthbe.supabase.co',
    supabaseKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxoYmN5aW5wZGd4d2hlbXd0aGJlIiwicm9sZSI6ImFub24iLCJpYXQiOjE2NTI2NTUwNjIsImV4cCI6MTk2ODIzMTA2Mn0.QtxRjTfo-dlA_0Kbof0mI1O3pjCPU_OE3tzWwtXlogA',
};